# 2048

A replica of the game 2048

## Add your files

- [ ] [Create](https://gitlab.com/-/experiment/new_project_readme_content:db5628ce7cf744fa160ccee87c12928a?https://docs.gitlab.com/ee/user/project/repository/web_editor.html#create-a-file) or [upload](https://gitlab.com/-/experiment/new_project_readme_content:db5628ce7cf744fa160ccee87c12928a?https://docs.gitlab.com/ee/user/project/repository/web_editor.html#upload-a-file) files
- [ ] [Add files using the command line](https://gitlab.com/-/experiment/new_project_readme_content:db5628ce7cf744fa160ccee87c12928a?https://docs.gitlab.com/ee/gitlab-basics/add-file.html#add-a-file-using-the-command-line) or push an existing Git repository with the following command:

```
cd existing_repo
git remote add origin https://gitlab.com/kdg-ti/integration-1.1/2021-2022/acs102a-group-13/2048.git
git branch -M main
git push -uf origin main
```

elliot hermans was here